import React from 'react'
import './ForgotPassword.css';
import logo from './images/mountain.jpg';
import { FaUser} from "react-icons/fa";
import { useState } from 'react';
import { Link } from 'react-router-dom';
const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const handleForgotPassword = async(e)=>{
        e.preventDefault();
        try{
            fetch('http://localhost:5000/forget',{
                method: 'POST',
                headers:{
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({email}),
            })
            .then((res)=>{
                res.json();
            })
            .then((data)=>{
                console.log(data);
                //setMessage(data.message);
                //setResetToken(data.resetToken);
            })
        }catch(error){
            console.log("Error: ", error);
            //setMessage('An error occurred while processing your request');
        }
    }
  return (
    <div className='login' style={{margin: '0',padding: '0',boxSizing: 'border-box'}}>
        <img src = {logo} style={{height:'100vh',width:'100vw',margin:'0',fontFamily:'Poppins',display:'flex',backgroundSize:'cover',backgroundPosition:'center'}} alt='mountain'/>
    <div className='wrapper' style={{background: 'transparent',
      border: '5px solid #ffffff33',
      boxShadow: '0 0 10px #00000033', marginTop: '-600px',marginLeft: '500px',width: '420px',justifyContent: 'center',alignItems: 'center',
      color: '#fff',
      borderRadius: '10px',
      padding: '30px 40px'}}>
        <form onSubmit={handleForgotPassword}>
            <h1 style={{fontSize: '36px',textAlign: 'center'}}>Forgot Password</h1>
            <div className="input-box">
                <input type="text" name="email" placeholder='Email' value={email} onChange={(e)=>setEmail(e.target.value)} required/>
                <FaUser className='icon'/>
            </div>
            
            <button type="submit">Send Reset Token</button><br></br>
            <div className="remember-forgot">
                <a href="#"><Link to='/reset-password'>Reset password</Link></a>
            </div>
            {message && <p style={{color: 'black', fontSize: 'large'}}>{message}</p>}
            
        </form>

    </div>
    </div>
  )
}

export default ForgotPassword
